A simple and friendly geometric sans serif font.

![](documentation/sample.png)